package AnalizadorLexico;

public class Token {

}
