package AnalizadorLexico.SemanticAction;

import AnalizadorLexico.LexicalAnalyzer;

public class AS_Numero_Start extends SemanticAction {

    public AS_Numero_Start(LexicalAnalyzer lexicalAnalyzer){
        super(lexicalAnalyzer);
    }

    public void Action(Character symbol) {
        lexical.buffer+= symbol;// no agrega el '
        lexical.index++;
        lexical.column++;
    }
}
